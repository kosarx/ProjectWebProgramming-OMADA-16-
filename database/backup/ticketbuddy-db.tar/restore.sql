--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Ticket Buddy";
--
-- Name: Ticket Buddy; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Ticket Buddy" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE "Ticket Buddy" OWNER TO postgres;

\connect -reuse-previous=on "dbname='Ticket Buddy'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE "Ticket Buddy"; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE "Ticket Buddy" IS 'The database for the Ticket Buddy web application -- UoP Summer 2024';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: CINEMA; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CINEMA" (
    "cinemaID" integer NOT NULL,
    movie_title character varying(255),
    director character varying(100),
    lead_roles character varying(255),
    rating character varying(50)
);


ALTER TABLE public."CINEMA" OWNER TO postgres;

--
-- Name: CINEMA_cinemaID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."CINEMA_cinemaID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."CINEMA_cinemaID_seq" OWNER TO postgres;

--
-- Name: CINEMA_cinemaID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."CINEMA_cinemaID_seq" OWNED BY public."CINEMA"."cinemaID";


--
-- Name: DISCOUNT_CATEGORY; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."DISCOUNT_CATEGORY" (
    "discountID" integer NOT NULL,
    discount_type character varying(50),
    discount_percentage double precision
);


ALTER TABLE public."DISCOUNT_CATEGORY" OWNER TO postgres;

--
-- Name: DISCOUNT_CATEGORY_discountID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."DISCOUNT_CATEGORY_discountID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."DISCOUNT_CATEGORY_discountID_seq" OWNER TO postgres;

--
-- Name: DISCOUNT_CATEGORY_discountID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."DISCOUNT_CATEGORY_discountID_seq" OWNED BY public."DISCOUNT_CATEGORY"."discountID";


--
-- Name: EVENT; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EVENT" (
    "eventID" integer NOT NULL,
    title character varying(255),
    description text,
    "imageURL" character varying(255),
    genre character varying(50),
    duration interval
);


ALTER TABLE public."EVENT" OWNER TO postgres;

--
-- Name: REVIEW; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."REVIEW" (
    "reviewID" integer NOT NULL,
    score integer,
    comment text,
    "userID" integer,
    date_written timestamp without time zone,
    "eventID" integer
);


ALTER TABLE public."REVIEW" OWNER TO postgres;

--
-- Name: EVENT_Average_Review_Score; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."EVENT_Average_Review_Score" AS
 SELECT e."eventID",
    e.title,
    avg(r.score) AS average_score
   FROM (public."EVENT" e
     LEFT JOIN public."REVIEW" r ON ((e."eventID" = r."eventID")))
  GROUP BY e."eventID", e.title
  ORDER BY e."eventID";


ALTER VIEW public."EVENT_Average_Review_Score" OWNER TO postgres;

--
-- Name: EVENT_SHOW; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."EVENT_SHOW" (
    "showID" integer NOT NULL,
    "eventID" integer,
    show_date date,
    show_time time without time zone,
    status character varying(50),
    "venueID" integer
);


ALTER TABLE public."EVENT_SHOW" OWNER TO postgres;

--
-- Name: TICKET; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."TICKET" (
    "ticketID" integer NOT NULL,
    ticket_number integer,
    status character varying(50),
    "categoryID" integer,
    "userID" integer,
    date_booked time without time zone,
    "discountID" integer,
    "showID" integer
);


ALTER TABLE public."TICKET" OWNER TO postgres;

--
-- Name: VENUE; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."VENUE" (
    "venueID" integer NOT NULL,
    venue_name character varying(100),
    city character varying(50),
    address character varying(255)
);


ALTER TABLE public."VENUE" OWNER TO postgres;

--
-- Name: Venue_HAS_Seat_Cat; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Venue_HAS_Seat_Cat" (
    "venueID" integer NOT NULL,
    "categoryID" integer NOT NULL,
    seat_num integer
);


ALTER TABLE public."Venue_HAS_Seat_Cat" OWNER TO postgres;

--
-- Name: VENUE_Total_Capacity; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."VENUE_Total_Capacity" AS
 SELECT v."venueID",
    v.venue_name,
    sum(vs.seat_num) AS total_capacity
   FROM (public."VENUE" v
     JOIN public."Venue_HAS_Seat_Cat" vs ON ((v."venueID" = vs."venueID")))
  GROUP BY v."venueID", v.venue_name, v.city, v.address
  ORDER BY v."venueID";


ALTER VIEW public."VENUE_Total_Capacity" OWNER TO postgres;

--
-- Name: EVENT_SHOW_Remaining_Capacity; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."EVENT_SHOW_Remaining_Capacity" AS
 SELECT es."showID",
    es."venueID",
    vtc.total_capacity,
    (vtc.total_capacity - COALESCE(sum(
        CASE
            WHEN ((t.status)::text = 'BOOKED'::text) THEN 1
            ELSE 0
        END), (0)::bigint)) AS remaining_capacity
   FROM ((public."EVENT_SHOW" es
     JOIN public."VENUE_Total_Capacity" vtc ON ((es."venueID" = vtc."venueID")))
     LEFT JOIN public."TICKET" t ON ((es."showID" = t."showID")))
  GROUP BY es."showID", es."eventID", es.show_date, es.show_time, es.status, es."venueID", vtc.total_capacity;


ALTER VIEW public."EVENT_SHOW_Remaining_Capacity" OWNER TO postgres;

--
-- Name: EVENT_SHOW_showID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EVENT_SHOW_showID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EVENT_SHOW_showID_seq" OWNER TO postgres;

--
-- Name: EVENT_SHOW_showID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EVENT_SHOW_showID_seq" OWNED BY public."EVENT_SHOW"."showID";


--
-- Name: EVENT_eventID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."EVENT_eventID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."EVENT_eventID_seq" OWNER TO postgres;

--
-- Name: EVENT_eventID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."EVENT_eventID_seq" OWNED BY public."EVENT"."eventID";


--
-- Name: MUSIC; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."MUSIC" (
    "musicID" integer NOT NULL,
    artists character varying(255),
    opening_act character varying(255)
);


ALTER TABLE public."MUSIC" OWNER TO postgres;

--
-- Name: MUSIC_musicID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."MUSIC_musicID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."MUSIC_musicID_seq" OWNER TO postgres;

--
-- Name: MUSIC_musicID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."MUSIC_musicID_seq" OWNED BY public."MUSIC"."musicID";


--
-- Name: REVIEW_reviewID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."REVIEW_reviewID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."REVIEW_reviewID_seq" OWNER TO postgres;

--
-- Name: REVIEW_reviewID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."REVIEW_reviewID_seq" OWNED BY public."REVIEW"."reviewID";


--
-- Name: SEAT_CATEGORY; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SEAT_CATEGORY" (
    "categoryID" integer NOT NULL,
    category_name character varying(50)
);


ALTER TABLE public."SEAT_CATEGORY" OWNER TO postgres;

--
-- Name: SEAT_CATEGORY_categoryID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SEAT_CATEGORY_categoryID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SEAT_CATEGORY_categoryID_seq" OWNER TO postgres;

--
-- Name: SEAT_CATEGORY_categoryID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SEAT_CATEGORY_categoryID_seq" OWNED BY public."SEAT_CATEGORY"."categoryID";


--
-- Name: Sets_Price; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sets_Price" (
    "showID" integer NOT NULL,
    "categoryID" integer NOT NULL,
    seat_price double precision
);


ALTER TABLE public."Sets_Price" OWNER TO postgres;

--
-- Name: THEATER; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."THEATER" (
    "theaterID" integer NOT NULL,
    play_title character varying(255),
    director character varying(100),
    scriptwriter character varying(100),
    lead_roles character varying(255)
);


ALTER TABLE public."THEATER" OWNER TO postgres;

--
-- Name: THEATER_theaterID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."THEATER_theaterID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."THEATER_theaterID_seq" OWNER TO postgres;

--
-- Name: THEATER_theaterID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."THEATER_theaterID_seq" OWNED BY public."THEATER"."theaterID";


--
-- Name: TICKET_Final_Price; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public."TICKET_Final_Price" AS
 SELECT t."ticketID",
    s.seat_price,
    d.discount_percentage,
    (s.seat_price * ((1)::double precision - (COALESCE(d.discount_percentage, (0)::double precision) / (100)::double precision))) AS final_price
   FROM ((public."TICKET" t
     JOIN public."Sets_Price" s ON (((t."showID" = s."showID") AND (t."categoryID" = s."categoryID"))))
     LEFT JOIN public."DISCOUNT_CATEGORY" d ON ((t."discountID" = d."discountID")));


ALTER VIEW public."TICKET_Final_Price" OWNER TO postgres;

--
-- Name: TICKET_ticketID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."TICKET_ticketID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."TICKET_ticketID_seq" OWNER TO postgres;

--
-- Name: TICKET_ticketID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."TICKET_ticketID_seq" OWNED BY public."TICKET"."ticketID";


--
-- Name: USER; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."USER" (
    "userID" integer NOT NULL,
    username character varying(50),
    password character varying(255),
    full_name character varying(100),
    email character varying(255),
    registration_date date,
    "profile_imageURL" character varying(255)
);


ALTER TABLE public."USER" OWNER TO postgres;

--
-- Name: USER_userID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."USER_userID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."USER_userID_seq" OWNER TO postgres;

--
-- Name: USER_userID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."USER_userID_seq" OWNED BY public."USER"."userID";


--
-- Name: VENUE_venueID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."VENUE_venueID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."VENUE_venueID_seq" OWNER TO postgres;

--
-- Name: VENUE_venueID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."VENUE_venueID_seq" OWNED BY public."VENUE"."venueID";


--
-- Name: CINEMA cinemaID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CINEMA" ALTER COLUMN "cinemaID" SET DEFAULT nextval('public."CINEMA_cinemaID_seq"'::regclass);


--
-- Name: DISCOUNT_CATEGORY discountID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DISCOUNT_CATEGORY" ALTER COLUMN "discountID" SET DEFAULT nextval('public."DISCOUNT_CATEGORY_discountID_seq"'::regclass);


--
-- Name: EVENT eventID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EVENT" ALTER COLUMN "eventID" SET DEFAULT nextval('public."EVENT_eventID_seq"'::regclass);


--
-- Name: EVENT_SHOW showID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EVENT_SHOW" ALTER COLUMN "showID" SET DEFAULT nextval('public."EVENT_SHOW_showID_seq"'::regclass);


--
-- Name: MUSIC musicID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MUSIC" ALTER COLUMN "musicID" SET DEFAULT nextval('public."MUSIC_musicID_seq"'::regclass);


--
-- Name: REVIEW reviewID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."REVIEW" ALTER COLUMN "reviewID" SET DEFAULT nextval('public."REVIEW_reviewID_seq"'::regclass);


--
-- Name: SEAT_CATEGORY categoryID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SEAT_CATEGORY" ALTER COLUMN "categoryID" SET DEFAULT nextval('public."SEAT_CATEGORY_categoryID_seq"'::regclass);


--
-- Name: THEATER theaterID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."THEATER" ALTER COLUMN "theaterID" SET DEFAULT nextval('public."THEATER_theaterID_seq"'::regclass);


--
-- Name: TICKET ticketID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKET" ALTER COLUMN "ticketID" SET DEFAULT nextval('public."TICKET_ticketID_seq"'::regclass);


--
-- Name: USER userID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."USER" ALTER COLUMN "userID" SET DEFAULT nextval('public."USER_userID_seq"'::regclass);


--
-- Name: VENUE venueID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VENUE" ALTER COLUMN "venueID" SET DEFAULT nextval('public."VENUE_venueID_seq"'::regclass);


--
-- Data for Name: CINEMA; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4916.dat

--
-- Data for Name: DISCOUNT_CATEGORY; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4926.dat

--
-- Data for Name: EVENT; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4910.dat

--
-- Data for Name: EVENT_SHOW; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4922.dat

--
-- Data for Name: MUSIC; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4914.dat

--
-- Data for Name: REVIEW; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4912.dat

--
-- Data for Name: SEAT_CATEGORY; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4924.dat

--
-- Data for Name: Sets_Price; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4930.dat

--
-- Data for Name: THEATER; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4918.dat

--
-- Data for Name: TICKET; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4928.dat

--
-- Data for Name: USER; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4908.dat

--
-- Data for Name: VENUE; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4920.dat

--
-- Data for Name: Venue_HAS_Seat_Cat; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/4929.dat

--
-- Name: CINEMA_cinemaID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."CINEMA_cinemaID_seq"', 1, false);


--
-- Name: DISCOUNT_CATEGORY_discountID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."DISCOUNT_CATEGORY_discountID_seq"', 1, false);


--
-- Name: EVENT_SHOW_showID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EVENT_SHOW_showID_seq"', 1, false);


--
-- Name: EVENT_eventID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."EVENT_eventID_seq"', 1, false);


--
-- Name: MUSIC_musicID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."MUSIC_musicID_seq"', 1, false);


--
-- Name: REVIEW_reviewID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."REVIEW_reviewID_seq"', 1, false);


--
-- Name: SEAT_CATEGORY_categoryID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SEAT_CATEGORY_categoryID_seq"', 1, false);


--
-- Name: THEATER_theaterID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."THEATER_theaterID_seq"', 1, false);


--
-- Name: TICKET_ticketID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."TICKET_ticketID_seq"', 1, false);


--
-- Name: USER_userID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."USER_userID_seq"', 1, false);


--
-- Name: VENUE_venueID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."VENUE_venueID_seq"', 1, false);


--
-- Name: CINEMA CINEMA_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CINEMA"
    ADD CONSTRAINT "CINEMA_pkey" PRIMARY KEY ("cinemaID");


--
-- Name: DISCOUNT_CATEGORY DISCOUNT_CATEGORY_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."DISCOUNT_CATEGORY"
    ADD CONSTRAINT "DISCOUNT_CATEGORY_pkey" PRIMARY KEY ("discountID");


--
-- Name: EVENT_SHOW EVENT_SHOW_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EVENT_SHOW"
    ADD CONSTRAINT "EVENT_SHOW_pkey" PRIMARY KEY ("showID");


--
-- Name: EVENT EVENT_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EVENT"
    ADD CONSTRAINT "EVENT_pkey" PRIMARY KEY ("eventID");


--
-- Name: MUSIC MUSIC_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MUSIC"
    ADD CONSTRAINT "MUSIC_pkey" PRIMARY KEY ("musicID");


--
-- Name: REVIEW REVIEW_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."REVIEW"
    ADD CONSTRAINT "REVIEW_pkey" PRIMARY KEY ("reviewID");


--
-- Name: SEAT_CATEGORY SEAT_CATEGORY_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SEAT_CATEGORY"
    ADD CONSTRAINT "SEAT_CATEGORY_pkey" PRIMARY KEY ("categoryID");


--
-- Name: Sets_Price Sets_Price_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sets_Price"
    ADD CONSTRAINT "Sets_Price_pkey" PRIMARY KEY ("showID", "categoryID");


--
-- Name: THEATER THEATER_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."THEATER"
    ADD CONSTRAINT "THEATER_pkey" PRIMARY KEY ("theaterID");


--
-- Name: TICKET TICKET_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKET"
    ADD CONSTRAINT "TICKET_pkey" PRIMARY KEY ("ticketID");


--
-- Name: USER USER_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."USER"
    ADD CONSTRAINT "USER_pkey" PRIMARY KEY ("userID");


--
-- Name: VENUE VENUE_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."VENUE"
    ADD CONSTRAINT "VENUE_pkey" PRIMARY KEY ("venueID");


--
-- Name: Venue_HAS_Seat_Cat Venue_HAS_Seat_Cat_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Venue_HAS_Seat_Cat"
    ADD CONSTRAINT "Venue_HAS_Seat_Cat_pkey" PRIMARY KEY ("venueID", "categoryID");


--
-- Name: CINEMA CINEMA_cinemaID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CINEMA"
    ADD CONSTRAINT "CINEMA_cinemaID_fkey" FOREIGN KEY ("cinemaID") REFERENCES public."EVENT"("eventID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: EVENT_SHOW EVENT_SHOW_eventID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EVENT_SHOW"
    ADD CONSTRAINT "EVENT_SHOW_eventID_fkey" FOREIGN KEY ("eventID") REFERENCES public."EVENT"("eventID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: EVENT_SHOW EVENT_SHOW_venueID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."EVENT_SHOW"
    ADD CONSTRAINT "EVENT_SHOW_venueID_fkey" FOREIGN KEY ("venueID") REFERENCES public."VENUE"("venueID") ON UPDATE CASCADE;


--
-- Name: MUSIC MUSIC_musicID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."MUSIC"
    ADD CONSTRAINT "MUSIC_musicID_fkey" FOREIGN KEY ("musicID") REFERENCES public."EVENT"("eventID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: REVIEW REVIEW_eventID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."REVIEW"
    ADD CONSTRAINT "REVIEW_eventID_fkey" FOREIGN KEY ("eventID") REFERENCES public."EVENT"("eventID") ON UPDATE CASCADE;


--
-- Name: REVIEW REVIEW_userID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."REVIEW"
    ADD CONSTRAINT "REVIEW_userID_fkey" FOREIGN KEY ("userID") REFERENCES public."USER"("userID") ON UPDATE CASCADE;


--
-- Name: Sets_Price Sets_Price_categoryID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sets_Price"
    ADD CONSTRAINT "Sets_Price_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES public."SEAT_CATEGORY"("categoryID");


--
-- Name: Sets_Price Sets_Price_showID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sets_Price"
    ADD CONSTRAINT "Sets_Price_showID_fkey" FOREIGN KEY ("showID") REFERENCES public."EVENT_SHOW"("showID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: THEATER THEATER_theaterID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."THEATER"
    ADD CONSTRAINT "THEATER_theaterID_fkey" FOREIGN KEY ("theaterID") REFERENCES public."EVENT"("eventID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: TICKET TICKET_categoryID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKET"
    ADD CONSTRAINT "TICKET_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES public."SEAT_CATEGORY"("categoryID");


--
-- Name: TICKET TICKET_discountID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKET"
    ADD CONSTRAINT "TICKET_discountID_fkey" FOREIGN KEY ("discountID") REFERENCES public."DISCOUNT_CATEGORY"("discountID");


--
-- Name: TICKET TICKET_showID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKET"
    ADD CONSTRAINT "TICKET_showID_fkey" FOREIGN KEY ("showID") REFERENCES public."EVENT_SHOW"("showID") ON UPDATE CASCADE;


--
-- Name: TICKET TICKET_userID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."TICKET"
    ADD CONSTRAINT "TICKET_userID_fkey" FOREIGN KEY ("userID") REFERENCES public."USER"("userID") ON UPDATE CASCADE;


--
-- Name: Venue_HAS_Seat_Cat Venue_HAS_Seat_Cat_categoryID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Venue_HAS_Seat_Cat"
    ADD CONSTRAINT "Venue_HAS_Seat_Cat_categoryID_fkey" FOREIGN KEY ("categoryID") REFERENCES public."SEAT_CATEGORY"("categoryID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Venue_HAS_Seat_Cat Venue_HAS_Seat_Cat_venueID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Venue_HAS_Seat_Cat"
    ADD CONSTRAINT "Venue_HAS_Seat_Cat_venueID_fkey" FOREIGN KEY ("venueID") REFERENCES public."VENUE"("venueID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

